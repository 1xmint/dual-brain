# Reviews

Optional home for cross-provider review files.

Use this folder only if you want durable written review artifacts for
high-stakes work.

Review memos are optional.
The canonical slice doc should still hold the current launch state and review
resolution.

Example filename:

`auth-middleware-2026-04-26.md`

Most buyers will not need this on day one.
