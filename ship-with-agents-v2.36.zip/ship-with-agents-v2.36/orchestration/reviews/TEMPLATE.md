# Review Memo Template

Use this when a second brain or supervisory layer has a real review artifact
worth preserving.

Store live copies in:

- `reviews/`

```text
Review memo: <slug>
Date: <YYYY-MM-DD>
Current session:
Current role:
Artifact produced by:
Intended recipient:
Related slice:
Assurance level:

What I checked:
- ...

What I did not check:
- ...

Main concerns:
- ...

Approval status:
- approved as-is / approved as revised / revise before launch / revise before closeout / escalate

Next-action delivery:
- delivery mode:
- exact target:
- exact user action:

Notes:
- ...
```

Do not use a review memo for routine clean approval if the slice itself already
captures enough truth.
